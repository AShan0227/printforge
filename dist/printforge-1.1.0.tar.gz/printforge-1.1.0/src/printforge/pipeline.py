"""
PrintForge Core Pipeline
========================
Image → TripoSR Inference → SDF Conversion → Marching Cubes → Watertight Mesh → Print Optimization → 3MF

Each stage is a standalone function, composable into the full pipeline.
"""

import io
import os
import time
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import requests

logger = logging.getLogger(__name__)


HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/TripoSR"


@dataclass
class PipelineConfig:
    """Configuration for the PrintForge pipeline."""
    # TripoSR inference
    model_name: str = "stabilityai/TripoSR"
    device: str = "cuda"  # "cuda", "cpu", or "mps"
    inference_backend: str = "auto"  # "auto", "hunyuan3d", "api", "local", "placeholder"

    # Background removal
    remove_background: bool = True
    foreground_ratio: float = 0.85

    # SDF / Marching Cubes
    mc_resolution: int = 256  # Marching cubes grid resolution

    # Print optimization
    min_wall_thickness_mm: float = 0.4  # FDM minimum
    max_faces: int = 200_000  # Simplify if exceeding
    add_base: bool = False  # Add flat base for easier printing
    base_height_mm: float = 2.0

    # Output
    output_format: str = "3mf"  # "3mf" or "stl"
    scale_mm: float = 50.0  # Default size in mm


@dataclass
class PipelineResult:
    """Result of a pipeline execution."""
    mesh_path: str
    vertices: int
    faces: int
    is_watertight: bool
    wall_thickness_ok: bool
    duration_ms: float
    stages: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)


class PrintForgePipeline:
    """Main pipeline: Image → 3D printable mesh."""
    
    def __init__(self, config: Optional[PipelineConfig] = None):
        self.config = config or PipelineConfig()
        self._model = None
    
    def run(self, image_path: str, output_path: str, progress_callback=None) -> PipelineResult:
        """Execute the full pipeline.

        Args:
            progress_callback: Optional callable(stage: str, progress: float)
                               for real-time progress updates.
        """
        def _progress(stage: str, pct: float):
            if progress_callback:
                progress_callback(stage, pct)

        start = time.time()
        stages = {}
        warnings = []

        # Stage 1: Load and preprocess image
        logger.info("Stage 1: Loading image...")
        _progress("load_image", 0.0)
        t0 = time.time()
        image = self._load_image(image_path)
        stages["load_image"] = time.time() - t0

        # Stage 1.5: Background removal
        if self.config.remove_background:
            logger.info("Stage 1.5: Removing background...")
            _progress("remove_background", 0.15)
            t0 = time.time()
            image = self._remove_background(image)
            stages["remove_background"] = time.time() - t0

        # Stage 2: TripoSR inference → raw mesh
        logger.info("Stage 2: TripoSR inference...")
        _progress("inference", 0.25)
        t0 = time.time()
        raw_mesh = self._infer_3d(image)
        stages["inference"] = time.time() - t0
        
        # Stage 3: SDF conversion → watertight mesh
        logger.info("Stage 3: SDF watertight conversion...")
        _progress("watertight", 0.50)
        t0 = time.time()
        watertight_mesh = self._make_watertight(raw_mesh)
        stages["watertight"] = time.time() - t0

        # Stage 4: Print optimization
        logger.info("Stage 4: Print optimization...")
        _progress("optimization", 0.70)
        t0 = time.time()
        optimized_mesh, opt_warnings = self._optimize_for_print(watertight_mesh)
        warnings.extend(opt_warnings)
        stages["optimization"] = time.time() - t0

        # Stage 5: Export
        logger.info("Stage 5: Exporting...")
        _progress("export", 0.90)
        t0 = time.time()
        self._export(optimized_mesh, output_path)
        stages["export"] = time.time() - t0
        
        total_ms = (time.time() - start) * 1000
        
        result = PipelineResult(
            mesh_path=output_path,
            vertices=len(optimized_mesh.vertices) if optimized_mesh else 0,
            faces=len(optimized_mesh.faces) if optimized_mesh else 0,
            is_watertight=optimized_mesh.is_watertight if optimized_mesh else False,
            wall_thickness_ok=len([w for w in warnings if "wall" in w.lower()]) == 0,
            duration_ms=total_ms,
            stages=stages,
            warnings=warnings,
        )
        
        _progress("done", 1.0)
        logger.info(f"Pipeline complete: {result.vertices} vertices, {result.faces} faces, "
                     f"watertight={result.is_watertight}, {total_ms:.0f}ms")
        return result
    
    def _load_image(self, image_path: str):
        """Load and preprocess image for TripoSR."""
        from PIL import Image
        img = Image.open(image_path).convert("RGB")
        # TripoSR expects 512x512
        img = img.resize((512, 512), Image.LANCZOS)
        return img

    def _remove_background(self, image):
        """Remove background using rembg for cleaner TripoSR inference."""
        try:
            from rembg import remove as rembg_remove
        except ImportError:
            logger.warning("rembg not installed — skipping background removal")
            return image

        # rembg returns RGBA
        result = rembg_remove(image)
        # Composite onto neutral gray background (TripoSR convention)
        result_np = np.array(result).astype(np.float32) / 255.0
        rgb = result_np[:, :, :3]
        alpha = result_np[:, :, 3:4]
        composited = rgb * alpha + (1 - alpha) * 0.5

        from PIL import Image as PILImage
        # Resize foreground to fill ~85% of frame
        composited_img = PILImage.fromarray(
            (composited * 255.0).astype(np.uint8)
        ).convert("RGB")
        return composited_img

    def _infer_3d(self, image):
        """Run TripoSR inference using the configured backend."""
        backend = self.config.inference_backend

        if backend == "placeholder":
            logger.info("Using placeholder mesh (configured)")
            return self._create_placeholder_mesh()

        if backend in ("auto", "hunyuan3d"):
            mesh = self._infer_hunyuan3d(image)
            if mesh is not None:
                return mesh
            if backend == "hunyuan3d":
                raise RuntimeError("Hunyuan3D inference failed and backend is 'hunyuan3d'")

        if backend in ("auto", "api"):
            mesh = self._infer_hf_api(image)
            if mesh is not None:
                return mesh
            if backend == "api":
                raise RuntimeError("HuggingFace API inference failed and backend is 'api'")

        if backend in ("auto", "local"):
            mesh = self._infer_local(image)
            if mesh is not None:
                return mesh
            if backend == "local":
                raise RuntimeError("Local TripoSR inference failed and backend is 'local'")

        # auto fallback to placeholder
        logger.warning("All inference backends unavailable — using placeholder mesh")
        return self._create_placeholder_mesh()

    def _infer_hunyuan3d(self, image):
        """Run inference via Hunyuan3D-2 Gradio Space."""
        try:
            from gradio_client import Client, handle_file
        except ImportError:
            logger.info("gradio_client not installed — skipping Hunyuan3D backend")
            return None

        try:
            import trimesh
            import tempfile

            # Save PIL image to temp file for handle_file
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                image.save(tmp, format="PNG")
                temp_path = tmp.name

            client = Client("Tencent/Hunyuan3D-2")
            result = client.predict(
                "", handle_file(temp_path), None, None, None,
                api_name="/shape_generation",
            )

            # result[0]['value'] contains the GLB file path
            glb_path = result[0]["value"]
            mesh = trimesh.load(glb_path, file_type="glb", force="mesh")
            logger.info(f"Hunyuan3D inference OK: {len(mesh.vertices)} verts, {len(mesh.faces)} faces")

            # Clean up temp file
            os.unlink(temp_path)
            return mesh
        except Exception as e:
            logger.warning(f"Hunyuan3D inference failed: {e}")
            return None

    def _infer_hf_api(self, image):
        """Run inference via HuggingFace Inference API."""
        hf_token = os.environ.get("HF_TOKEN")
        if not hf_token:
            logger.info("HF_TOKEN not set — skipping HuggingFace API backend")
            return None

        try:
            buf = io.BytesIO()
            image.save(buf, format="PNG")
            image_bytes = buf.getvalue()

            resp = requests.post(
                HF_API_URL,
                headers={"Authorization": f"Bearer {hf_token}"},
                data=image_bytes,
                timeout=120,
            )
            resp.raise_for_status()

            # Response is GLB binary — load via trimesh
            import trimesh
            glb_data = io.BytesIO(resp.content)
            mesh = trimesh.load(glb_data, file_type="glb", force="mesh")
            logger.info(f"HF API inference OK: {len(mesh.vertices)} verts, {len(mesh.faces)} faces")
            return mesh
        except Exception as e:
            logger.warning(f"HuggingFace API inference failed: {e}")
            return None

    def _infer_local(self, image):
        """Run inference using local TripoSR model."""
        try:
            from tsr.system import TSR
            import torch
        except ImportError:
            logger.info("tsr package not available — skipping local backend")
            return None

        try:
            if self._model is None:
                # Pick best available device
                device = self.config.device
                if device == "cuda" and not torch.cuda.is_available():
                    device = "mps" if torch.backends.mps.is_available() else "cpu"
                elif device == "mps" and not torch.backends.mps.is_available():
                    device = "cpu"
                self.config.device = device

                logger.info(f"Loading TripoSR model: {self.config.model_name} on {device}")
                self._model = TSR.from_pretrained(
                    self.config.model_name,
                    config_name="config.yaml",
                    weight_name="model.ckpt",
                )
                self._model.to(device)

            with torch.no_grad():
                scene = self._model(image, device=self.config.device)

            mesh = scene.get_mesh(resolution=self.config.mc_resolution)
            logger.info(f"Local inference OK: {len(mesh.vertices)} verts, {len(mesh.faces)} faces")
            return mesh
        except Exception as e:
            logger.warning(f"Local TripoSR inference failed: {e}")
            return None

    def _create_placeholder_mesh(self):
        """Create a simple cube mesh for testing without TripoSR."""
        import trimesh
        return trimesh.creation.box(extents=[1.0, 1.0, 1.0])
    
    def _make_watertight(self, mesh):
        """Convert mesh to watertight using SDF → Marching Cubes."""
        import trimesh
        
        if hasattr(mesh, "is_watertight") and mesh.is_watertight:
            logger.info("Mesh is already watertight, skipping SDF conversion")
            return mesh
        
        # Convert to trimesh if not already
        if not isinstance(mesh, trimesh.Trimesh):
            if hasattr(mesh, "vertices") and hasattr(mesh, "faces"):
                mesh = trimesh.Trimesh(
                    vertices=mesh.vertices,
                    faces=mesh.faces,
                )
            else:
                raise ValueError("Cannot convert mesh to trimesh format")
        
        # Method: Voxelize → Fill → Marching Cubes → guaranteed watertight
        try:
            # Voxelize the mesh, fill interior, then extract surface
            pitch = mesh.bounding_box.extents.max() / self.config.mc_resolution
            voxel_grid = mesh.voxelized(pitch).fill()

            # Marching cubes on filled voxels → guaranteed watertight
            watertight = voxel_grid.marching_cubes
            
            logger.info(f"SDF conversion: {len(mesh.faces)} → {len(watertight.faces)} faces, "
                        f"watertight={watertight.is_watertight}")
            return watertight
            
        except Exception as e:
            logger.warning(f"SDF conversion failed ({e}), attempting repair instead")
            # Fallback: use trimesh repair
            trimesh.repair.fix_normals(mesh)
            trimesh.repair.fix_winding(mesh)
            trimesh.repair.fill_holes(mesh)
            return mesh
    
    def _optimize_for_print(self, mesh):
        """Optimize mesh for 3D printing."""
        import trimesh
        warnings = []
        
        # 1. Scale to target size
        current_size = mesh.bounding_box.extents.max()
        if current_size > 0:
            scale_factor = self.config.scale_mm / current_size
            mesh.apply_scale(scale_factor)
        
        # 2. Simplify if too many faces (numpy subsampling — no native deps)
        if len(mesh.faces) > self.config.max_faces:
            original_count = len(mesh.faces)
            step = max(1, len(mesh.faces) // self.config.max_faces)
            keep = np.arange(0, len(mesh.faces), step)[:self.config.max_faces]
            mesh = mesh.submesh([keep], append=True)
            logger.info(f"Simplified: {original_count} → {len(mesh.faces)} faces")
        
        # 3. Fix normals
        trimesh.repair.fix_normals(mesh)
        
        # 4. Check wall thickness (approximate)
        if hasattr(mesh, "bounding_box"):
            min_extent = mesh.bounding_box.extents.min()
            if min_extent < self.config.min_wall_thickness_mm:
                warnings.append(f"Wall thickness warning: min extent {min_extent:.2f}mm < {self.config.min_wall_thickness_mm}mm")
        
        # 5. Add base if requested
        if self.config.add_base:
            base = trimesh.creation.box(
                extents=[
                    mesh.bounding_box.extents[0] * 1.1,
                    mesh.bounding_box.extents[1] * 1.1,
                    self.config.base_height_mm,
                ]
            )
            base.apply_translation([
                mesh.bounding_box.centroid[0],
                mesh.bounding_box.centroid[1],
                mesh.bounds[0][2] - self.config.base_height_mm / 2,
            ])
            mesh = trimesh.util.concatenate([mesh, base])
        
        # 6. Final watertight check
        if not mesh.is_watertight:
            warnings.append("Final mesh is not watertight. May cause slicing issues.")
            trimesh.repair.fill_holes(mesh)
        
        return mesh, warnings
    
    def _export(self, mesh, output_path: str):
        """Export mesh in the configured format."""
        output_path = Path(output_path)
        
        if self.config.output_format == "3mf" or output_path.suffix == ".3mf":
            # 3MF export
            try:
                mesh.export(str(output_path), file_type="3mf")
            except Exception:
                # Fallback to STL if 3MF export fails
                stl_path = output_path.with_suffix(".stl")
                mesh.export(str(stl_path), file_type="stl")
                logger.warning(f"3MF export failed, saved as STL: {stl_path}")
        else:
            mesh.export(str(output_path), file_type="stl")
